Please include:

* URL for site (if possible)
* Output of run with `--debug-requests`.
* OS & installation method (e.g. Kali Rolling installed via pip)
